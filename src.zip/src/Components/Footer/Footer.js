import "./Footer.css";

const Footer = () => {
    return (
        <footer className="footer">
            <div>Developed By Sayvon & Sergio</div>
            <div>2025</div>
        </footer>
    );
};

export default Footer;